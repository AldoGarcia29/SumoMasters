export const DURACION_COMBATE_DEFAULT_MIN = 15;
export const LIVE_TTL_MS = 8_000;
export const LISTA_TTL_MS = 30_000;
export const liveKey = (id: string) => `live:${id}`;
export const LISTA_KEY = 'lista';
